"use client";

import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Settings, Shield, Sliders } from "lucide-react";

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">System Configuration</h1>
        <p className="text-sm text-muted-foreground mt-1">Manage global environment variables and architecture configurations</p>
      </div>

      <div className="space-y-6 max-w-2xl">
        <div className="border border-border bg-card/40 p-6 rounded-xl space-y-4">
          <h3 className="text-base font-semibold flex items-center gap-2 border-b border-border pb-2">
            <Sliders className="h-4 w-4 text-emerald-500" /> Platform Integration Config
          </h3>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase">n8n Gateway Endpoint</label>
              <Input type="text" placeholder="https://n8n.domain.mesh/v1/webhooks/..." className="bg-background/50 font-mono text-xs" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground uppercase">Voice Agent Profile ID</label>
              <Input type="text" placeholder="agent_v1_7f309a..." className="bg-background/50 font-mono text-xs" />
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button className="bg-emerald-600 hover:bg-emerald-500 text-white px-6">Commit State Mutations</Button>
        </div>
      </div>
    </div>
  );
}