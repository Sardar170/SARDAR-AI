"use client";

import React from "react";
import { Activity, ShieldCheck, Cpu } from "lucide-react";

export default function TelemetryPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Telemetry Matrix</h1>
        <p className="text-sm text-muted-foreground mt-1">Live data streams and node monitoring interface</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="border border-border bg-card/40 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <span>Cluster CPU</span>
            <Cpu className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-mono font-bold">14.2%</div>
        </div>

        <div className="border border-border bg-card/40 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <span>Memory Allocated</span>
            <Activity className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-mono font-bold">512 MB</div>
        </div>

        <div className="border border-border bg-card/40 p-5 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <span>Node Health</span>
            <ShieldCheck className="h-4 w-4 text-purple-400" />
          </div>
          <div className="text-2xl font-mono font-bold">100.0%</div>
        </div>
      </div>
    </div>
  );
}