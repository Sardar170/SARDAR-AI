"use client";

import React, { useEffect, useState } from "react";
import { MicButton } from "@/components/voice/mic-button";
import { Visualizer } from "@/components/voice/visualizer";
import { useVoiceAI } from "@/hooks/use-voice-ai";
import { formatDuration } from "@/lib/utils";
import { Shield, Radio, Volume2 } from "lucide-react";

export default function VoiceConsolePage() {
  const { isActive, isConnecting, startSession, stopSession } = useVoiceAI();
  const [seconds, setSeconds] = useState<number>(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds(prev => prev + 1);
      }, 1000);
    } else {
      setSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Voice Engine Interface</h1>
        <p className="text-sm text-muted-foreground mt-1">Real-time low-latency bidirectional conversation pipeline portal</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 border border-border bg-card/30 rounded-2xl p-8 flex flex-col items-center justify-center min-h-[400px] space-y-6 relative overflow-hidden">
          <div className="absolute top-4 left-4 flex items-center gap-2 text-xs font-mono px-2.5 py-1 rounded-full border border-border bg-background/50">
            <Radio className={`h-3 w-3 ${isActive ? "text-emerald-500 animate-pulse" : "text-muted-foreground"}`} />
            {isActive ? "SESSION BROADCAST ACTIVE" : "CHANNEL DISCONNECTED"}
          </div>

          <div className="absolute top-4 right-4 text-sm font-mono tracking-widest text-muted-foreground">
            {formatDuration(seconds)}
          </div>

          <Visualizer isActive={isActive} />

          <div className="flex flex-col items-center space-y-2">
            <MicButton
              isActive={isActive}
              isConnecting={isConnecting}
              onStart={startSession}
              onStop={stopSession}
            />
            <span className="text-xs font-semibold tracking-wider text-muted-foreground uppercase pt-2">
              {isActive ? "Tap to terminate payload" : "Initialize stream link"}
            </span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="border border-border bg-card/40 p-5 rounded-xl space-y-3">
            <h3 className="text-sm font-semibold tracking-wider uppercase text-muted-foreground flex items-center gap-2">
              <Shield className="h-4 w-4 text-emerald-500" /> Pipeline Security
            </h3>
            <div className="text-xs space-y-1.5 font-mono text-muted-foreground">
              <div>Encoding: <span className="text-foreground">Opus 48kHz Stereo</span></div>
              <div>Protocol: <span className="text-foreground">Secure WebRTC / WSS</span></div>
              <div>Encryption: <span className="text-foreground">AES-GCM-256</span></div>
            </div>
          </div>

          <div className="border border-border bg-card/40 p-5 rounded-xl space-y-3">
            <h3 className="text-sm font-semibold tracking-wider uppercase text-muted-foreground flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-cyan-400" /> Operational Metrics
            </h3>
            <div className="text-xs space-y-1.5 font-mono text-muted-foreground">
              <div>Avg Latency: <span className="text-foreground">{isActive ? "142ms" : "0ms"}</span></div>
              <div>Jitter Buffering: <span className="text-foreground">Adaptive (20ms max)</span></div>
              <div>VAD Threshold: <span className="text-foreground">-42 dB</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}