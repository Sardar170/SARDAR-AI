"use client";

import React from "react";
import { Cpu, Zap, Activity, ShieldCheck } from "lucide-react";

export default function DashboardOverview() {
  const cards = [
    { title: "Supabase Integrity", status: "Operational", desc: "Realtime subscription stream alive", icon: ShieldCheck, color: "text-emerald-500" },
    { title: "n8n Webhook Listener", status: "Active Node", desc: "Listening on /api/n8n listener group", icon: Zap, color: "text-amber-500" },
    { title: "Voice AI Engine", status: "Standby Mode", desc: "Asynchronous stream initialization ready", icon: Cpu, color: "text-cyan-400" },
    { title: "System Overlords Cluster", status: "Nominal", desc: "Telemetry monitoring 0ms variance response", icon: Activity, color: "text-purple-400" }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Control Infrastructure</h1>
        <p className="text-sm text-muted-foreground mt-1">Operational landscape telemetry profile matrix</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} className="border border-border bg-card/40 p-5 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{card.title}</span>
                <Icon className={`h-5 w-5 ${card.color}`} />
              </div>
              <div>
                <div className="text-xl font-bold font-mono tracking-tight">{card.status}</div>
                <p className="text-xs text-muted-foreground mt-0.5">{card.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="border border-border bg-card/20 rounded-xl p-6 h-64 flex flex-col justify-between">
        <div className="space-y-1">
          <h2 className="text-lg font-semibold">Core Terminal Node Connection</h2>
          <p className="text-sm text-muted-foreground">Synchronous logging parameters from execution runtime thread</p>
        </div>
        <div className="bg-black/40 border border-border rounded-lg p-4 font-mono text-xs text-emerald-400/80 space-y-1 flex-1 mt-4 overflow-y-auto">
          <div>[2026-07-18T14:32:01Z] INF SARDAR AI system initialization initialized successfully.</div>
          <div>[2026-07-18T14:32:02Z] INF Loaded Supabase client integration layer configurations.</div>
          <div>[2026-07-18T14:32:02Z] INF n8n webhook listener online mapping path: /api/n8n</div>
          <div>[2026-07-18T14:32:03Z] INF Voice AI dynamic session channel ready for client query initialization hook.</div>
        </div>
      </div>
    </div>
  );
}