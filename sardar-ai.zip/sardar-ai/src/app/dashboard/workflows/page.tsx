"use client";

import React, { useState } from "react";
import { triggerWorkflow } from "@/services/n8n";
import { Button } from "@/components/ui/button";
import { Zap, Play, CheckCircle2 } from "lucide-react";

export default function WorkflowsHubPage() {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);

  const dispatchTestWorkflow = async () => {
    setIsRunning(true);
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [...prev, `[${timestamp}] Dispatched trigger payload block to n8n webhook grid...`]);

    try {
      await triggerWorkflow("USER_MANUAL_TRIGGER", {
        sourceModule: "SARDAR_AI_DASHBOARD_CONSOLE",
        metaInfo: "Operational environment synchronization validation"
      });
      
      setLogs(prev => [
        ...prev, 
        `[${new Date().toLocaleTimeString()}] Handshake finalized. n8n workflow matrix acknowledged receipt context structural signature successfully.`
      ]);
    } catch (err) {
      setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ERR: Dispatch transport error occurred.`]);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Automation Engine Grid</h1>
        <p className="text-sm text-muted-foreground mt-1">Configure orchestration pathways mapping into localized external n8n modules</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 border border-border bg-card/40 p-6 rounded-xl flex flex-col justify-between h-64">
          <div className="space-y-2">
            <div className="h-10 w-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
              <Zap className="h-5 w-5 text-amber-500" />
            </div>
            <h3 className="text-lg font-semibold mt-2">Manual Signal Bridge</h3>
            <p className="text-xs text-muted-foreground">Dispatches atomic synchronization payload block signature onto configured remote n8n orchestration nodes</p>
          </div>
          <Button 
            onClick={dispatchTestWorkflow} 
            disabled={isRunning}
            className="w-full bg-amber-600 hover:bg-amber-500 text-white flex items-center gap-2"
          >
            <Play className="h-4 w-4 fill-current" /> Execute Trigger Node
          </Button>
        </div>

        <div className="md:col-span-2 border border-border bg-card/20 rounded-xl p-6 flex flex-col justify-between h-64">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Live Orchestration Audit Event Logs</div>
          <div className="bg-black/50 border border-border rounded-lg p-4 font-mono text-xs text-amber-400/90 flex-1 overflow-y-auto space-y-1.5">
            {logs.length === 0 ? (
              <div className="text-muted-foreground/60 italic">System event line interface idle. Initiate trigger vector...</div>
            ) : (
              logs.map((log, index) => <div key={index}>{log}</div>)
            )}
          </div>
        </div>
      </div>
    </div>
  );
}