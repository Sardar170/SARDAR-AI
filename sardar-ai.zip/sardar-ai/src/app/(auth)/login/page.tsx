"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Cpu, Loader2 } from "lucide-react";
import Link from "next/link";

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => (window.location.href = "/dashboard"), 1200);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md border border-border bg-card/30 rounded-xl p-8 backdrop-blur-sm shadow-2xl">
        <div className="flex flex-col items-center mb-8">
          <div className="h-12 w-12 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-3">
            <Cpu className="h-6 w-6 text-emerald-500" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Access SARDAR AI</h1>
          <p className="text-sm text-muted-foreground mt-1">Authenticate node connection credentials</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Node User ID</label>
            <Input required type="email" placeholder="operator@sardar.ai" className="bg-background/50" />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Passkey Security String</label>
            <Input required type="password" placeholder="••••••••••••" className="bg-background/50" />
          </div>
          <Button type="submit" disabled={isLoading} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white mt-2">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Establish Node Connection"}
          </Button>
        </form>
        <div className="mt-6 text-center text-xs text-muted-foreground">
          Protected environment matrix system. <Link href="/" className="underline hover:text-foreground">Terminate session fallback</Link>
        </div>
      </div>
    </div>
  );
}