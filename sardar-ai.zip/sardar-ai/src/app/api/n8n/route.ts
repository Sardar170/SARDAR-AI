import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const payload = await req.json();
    console.log("Webhook payload safely consumed from n8n deployment pipeline:", payload);

    return NextResponse.json({
      status: "acknowledged",
      receivedAt: new Date().toISOString(),
      origin: "SARDAR_AI_AUTOMATION_HUB"
    }, { status: 200 });

  } catch (error) {
    console.error("Critical parsing error within n8n consumer runtime:", error);
    return NextResponse.json({ error: "Malformed payload request structure" }, { status: 400 });
  }
}