"use client";

import React from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Cpu, Zap, Database, Mic, ArrowRight } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background selection:bg-emerald-500/30">
      <header className="border-b border-border/40 bg-background/50 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto max-w-7xl h-16 flex items-center justify-between px-4">
          <div className="flex items-center gap-2.5 font-bold tracking-widest text-lg">
            <Cpu className="h-5 w-5 text-emerald-500" />
            <span>SARDAR AI</span>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm" className="border-border hover:bg-secondary">
              Enter Console
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-4 py-20 text-center relative overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/5 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-4xl mx-auto space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-emerald-500/20 bg-emerald-500/5 text-xs text-emerald-400 font-mono uppercase tracking-wider mx-auto">
            <Zap className="h-3 w-3 fill-current" /> Next.js 15 Edge Stack Engine Ready
          </div>
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-foreground balance leading-[1.15]">
            Enterprise Autonomous Voice & <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
              Automation Infrastructure Matrix
            </span>
          </h1>
          <p className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto font-normal leading-relaxed">
            Clean-architecture orchestrator node with decoupled native integrations binding Supabase, n8n webhook nodes, and high-fidelity real-time audio streams.
          </p>
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/dashboard">
              <Button size="lg" className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium px-8 flex items-center gap-2 w-full sm:w-auto shadow-lg shadow-emerald-600/10">
                Initialize Cluster Core <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/login">
              <Button size="lg" variant="ghost" className="hover:bg-secondary/60 text-muted-foreground hover:text-foreground px-8 w-full sm:w-auto">
                Authenticate Operator
              </Button>
            </Link>
          </div>
        </div>

        <section className="container mx-auto max-w-6xl px-4 mt-32 grid grid-cols-1 sm:grid-cols-3 gap-6 relative z-10 text-left">
          {[
            { title: "Supabase SSR Identity", desc: "Native authentication and real-time structured state synchronizer layer.", icon: Database, color: "text-emerald-500" },
            { title: "n8n Integration Vector", desc: "Asynchronous background execution triggers dispatched straight to runtime webhooks.", icon: Zap, color: "text-amber-500" },
            { title: "Low-latency Voice AI", desc: "Low-jitter full-duplex WebRTC bidirectional media audio stream pipelines.", icon: Mic, color: "text-cyan-400" }
          ].map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div key={idx} className="border border-border bg-card/20 p-6 rounded-2xl space-y-3 backdrop-blur-sm transition-all duration-300 hover:border-border/80 hover:bg-card/30">
                <div className="h-9 w-9 rounded-xl bg-background border border-border flex items-center justify-center shadow-inner">
                  <Icon className={`h-4 w-4 ${feat.color}`} />
                </div>
                <h3 className="text-base font-semibold tracking-tight text-foreground">{feat.title}</h3>
                <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">{feat.desc}</p>
              </div>
            );
          })}
        </section>
      </main>

      <footer className="border-t border-border/40 bg-card/10 text-xs text-muted-foreground font-mono">
        <div className="container mx-auto max-w-7xl h-12 flex items-center justify-between px-4">
          <div>SARDAR AI — ALL SYSTEMS SECURED [2026]</div>
          <div>EDGE MODE ON</div>
        </div>
      </footer>
    </div>
  );
}