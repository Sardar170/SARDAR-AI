export interface VoiceConfig {
  agentId: string;
  sampleRate: number;
}

export class VoiceService {
  private static instance: VoiceService;
  private config: VoiceConfig | null = null;

  private constructor() {}

  public static getInstance(): VoiceService {
    if (!VoiceService.instance) {
      VoiceService.instance = new VoiceService();
    }
    return VoiceService.instance;
  }

  public init(config: VoiceConfig) {
    this.config = config;
  }

  public async requestSessionToken(): Promise<{ token: string; url: string }> {
    if (!this.config?.agentId) {
      throw new Error("VoiceService configuration is missing agentId.");
    }

    const response = await fetch("/api/voice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agentId: this.config.agentId }),
    });

    if (!response.ok) {
      throw new Error("Failed to initialize remote voice pipeline token.");
    }

    return response.json();
  }
}