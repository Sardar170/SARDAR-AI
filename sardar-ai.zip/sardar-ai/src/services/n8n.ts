const N8N_WEBHOOK_URL = process.env.N8N_WORKFLOW_WEBHOOK_URL;

export async function triggerWorkflow(eventName: string, payload: Record<string, any>) {
  if (!N8N_WEBHOOK_URL) {
    console.warn("n8n Webhook URL is missing.");
    return { mock: true, status: "acknowledged" };
  }

  try {
    const response = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event: eventName, timestamp: new Date().toISOString(), ...payload }),
    });

    if (!response.ok) throw new Error(`n8n responded with status: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error("Failed to route event to n8n:", error);
    throw error;
  }
}