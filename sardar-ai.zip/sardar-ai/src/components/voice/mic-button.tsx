"use client";

import React from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface MicButtonProps {
  isActive: boolean;
  isConnecting: boolean;
  onStart: () => void;
  onStop: () => void;
}

export function MicButton({ isActive, isConnecting, onStart, onStop }: MicButtonProps) {
  if (isConnecting) {
    return (
      <Button disabled size="lg" className="rounded-full w-16 h-16 bg-muted text-muted-foreground animate-pulse">
        <Loader2 className="h-6 w-6 animate-spin" />
      </Button>
    );
  }

  return (
    <Button
      size="lg"
      onClick={isActive ? onStop : onStart}
      className={cn(
        "rounded-full w-16 h-16 flex items-center justify-center transition-all duration-300 shadow-lg",
        isActive 
          ? "bg-destructive text-destructive-foreground hover:bg-destructive/90 ring-4 ring-destructive/20" 
          : "bg-emerald-600 text-white hover:bg-emerald-500 ring-4 ring-emerald-500/10"
      )}
    >
      {isActive ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
    </Button>
  );
}