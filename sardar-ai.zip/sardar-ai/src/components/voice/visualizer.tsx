"use client";

import React, { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

interface VisualizerProps {
  isActive: boolean;
}

export function Visualizer({ isActive }: VisualizerProps) {
  const [bars, setBars] = useState<number[]>(new Array(12).fill(4));

  useEffect(() => {
    if (!isActive) {
      setBars(new Array(12).fill(4));
      return;
    }

    const interval = setInterval(() => {
      setBars(prev => prev.map(() => Math.floor(Math.random() * 36) + 6));
    }, 100);

    return () => clearInterval(interval);
  }, [isActive]);

  return (
    <div className="flex items-center justify-center gap-1.5 h-16 px-4">
      {bars.map((height, idx) => (
        <div
          key={idx}
          style={{ height: `${height}px` }}
          className={cn(
            "w-1 rounded-full transition-all duration-100 bg-foreground/60",
            isActive && "bg-gradient-to-t from-emerald-500 to-cyan-400 shadow-[0_0_10px_rgba(16,185,129,0.3)]"
          )}
        />
      ))}
    </div>
  );
}