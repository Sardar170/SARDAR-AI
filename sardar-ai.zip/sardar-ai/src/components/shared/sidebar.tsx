"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Mic, Settings, Sliders, LogOut, Radio } from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const pathname = usePathname();

  const links = [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/voice", label: "Voice Console", icon: Mic },
    { href: "/dashboard/workflows", label: "Automation Hub", icon: Sliders },
    { href: "/dashboard/telemetry", label: "Live Streams", icon: Radio },
    { href: "/dashboard/settings", label: "System Config", icon: Settings },
  ];

  return (
    <aside className="w-64 border-r border-border h-[calc(100vh-3.5rem)] flex flex-col justify-between p-4 bg-card/40">
      <div className="space-y-1.5">
        <div className="px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Navigation
        </div>
        {links.map((link) => {
          const Icon = link.icon;
          const active = pathname === link.href;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-all",
                active 
                  ? "bg-secondary text-foreground" 
                  : "text-muted-foreground hover:bg-secondary/40 hover:text-foreground"
              )}
            >
              <Icon className={cn("h-4 w-4", active ? "text-emerald-500" : "text-muted-foreground")} />
              {link.label}
            </Link>
          );
        })}
      </div>
      <button className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-muted-foreground rounded-md hover:bg-destructive/10 hover:text-destructive transition-all w-full mt-auto">
        <LogOut className="h-4 w-4" />
        Disconnect
      </button>
    </aside>
  );
}