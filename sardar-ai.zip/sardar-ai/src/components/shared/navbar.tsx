"use client";

import Link from "next/link";
import { Cpu, LayoutDashboard, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center space-x-2 font-bold text-lg tracking-wider">
            <Cpu className="h-5 w-5 text-emerald-500" />
            <span>SARDAR AI</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
            <Link href="/dashboard" className="transition-colors hover:text-foreground flex items-center gap-1.5">
              <LayoutDashboard className="h-4 w-4" /> Dashboard
            </Link>
            <Link href="/dashboard/workflows" className="transition-colors hover:text-foreground flex items-center gap-1.5">
              <Terminal className="h-4 w-4" /> Workflows
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/login">
            <Button variant="ghost" size="sm">Log In</Button>
          </Link>
          <Link href="/dashboard">
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-500 text-white">Console</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}