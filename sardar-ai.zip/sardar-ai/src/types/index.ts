export interface UserProfile {
  id: string;
  email: string;
  fullName?: string;
  avatarUrl?: string;
  createdAt: string;
}

export interface VoiceSession {
  id: string;
  status: "idle" | "connecting" | "active" | "error";
  duration: number;
  error?: string;
}

export interface AutomationWorkflow {
  id: string;
  name: string;
  status: "active" | "inactive";
  lastTriggered?: string;
}