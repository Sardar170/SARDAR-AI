"use client";

import { useState, useCallback } from "react";

export function useVoiceAI() {
  const [isActive, setIsActive] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);

  const startSession = useCallback(async () => {
    setIsConnecting(true);
    try {
      const res = await fetch("/api/voice", { method: "POST" });
      const { token } = await res.json();
      console.log("Voice channel connected with token:", token);
      setIsActive(true);
    } catch (err) {
      console.error("Voice initialization error:", err);
    } finally {
      setIsConnecting(false);
    }
  }, []);

  const stopSession = useCallback(() => {
    setIsActive(false);
  }, []);

  return { isActive, isConnecting, startSession, stopSession };
}